const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    title: "Custo3D",
    // Tenta pegar o ícone da pasta de build ou desenvolvimento
    icon: path.join(__dirname, '../public/assets/logo.png'),
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false // Ajuda a evitar bloqueios de carregamento local
    },
  });

  // Remove o menu padrão feio do Windows
  win.setMenuBarVisibility(false);

  const isDev = process.env.NODE_ENV === 'development';

  if (isDev) {
    // Em desenvolvimento: Carrega do Vite
    win.loadURL('http://localhost:5173');
    win.webContents.openDevTools();
  } else {
    // Em produção: Carrega o arquivo index.html gerado
    // O path.resolve ajuda a achar o caminho correto dentro do .exe
    const indexPath = path.resolve(__dirname, '../dist/index.html');
    win.loadFile(indexPath);
    
    // Descomente a linha abaixo se quiser ver erros no app final (para debug)
    // win.webContents.openDevTools(); 
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});